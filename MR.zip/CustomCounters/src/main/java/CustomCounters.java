
import java.io.IOException;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskCounter;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class CustomCounters extends Configured implements Tool 
{
	enum Temperature {
	MISSING,
	MALFORMED
	}

	static class MaxTemperatureMapperWithCounters
	extends Mapper<LongWritable, Text, Text, IntWritable> 
	{
	
		private NcdcRecordParser parser = new NcdcRecordParser();
		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException
		{
			parser.parse(value);
			if (parser.isValidTemperature())
			{
				int airTemperature = parser.getAirTemperature();
				context.write(new Text(parser.getYear()),
						new IntWritable(airTemperature));
			} 
			else
			{
				System.err.println("Ignoring possibly corrupt input: " + value);
				context.getCounter(Temperature.MALFORMED).increment(1);
				//context.getCounter("Category","Name");
			} 
		} //map function ends here
	  } //MAPPER ends here

	public static class MaxTemperatureReducerWithCounters
	extends Reducer<Text, IntWritable, Text, IntWritable> 
	{
		@Override
		public void reduce(Text key, Iterable<IntWritable> values,
			Context context)
			throws IOException, InterruptedException 
			{
				int maxValue = Integer.MIN_VALUE;
				for (IntWritable value : values) {
				maxValue = Math.max(maxValue, value.get());
			}
			context.write(key, new IntWritable(maxValue));
		}
	}
	
	@Override
	public int run(String[] args) throws Exception 
	{
		Job job = JobBuilder.parseInputAndOutput(this, getConf(), args);
		
		if (job == null) 
		{
		return -1;
		}

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		job.setMapperClass(MaxTemperatureMapperWithCounters.class);
		job.setCombinerClass(MaxTemperatureReducerWithCounters.class);
		job.setReducerClass(MaxTemperatureReducerWithCounters.class);
		//job.setNumReduceTasks(0);
		
		int jobResult = job.waitForCompletion(true) ? 0 : 1;
		Counters counters = job.getCounters();
		long badRecords = counters.findCounter(Temperature.MALFORMED).getValue();
		long totRecords = counters.findCounter(TaskCounter.MAP_INPUT_RECORDS).getValue();
				
		System.out.printf("Bad records: %s%n" , badRecords);
		System.out.printf("Total records: %s%n" , totRecords);
		System.out.printf("Percentage of bad records: %.5f" , (float) badRecords / totRecords);
		return jobResult;
	}

	public static void main(String[] args) throws Exception 
	{
		int exitCode = ToolRunner.run(new CustomCounters(), args);
		System.exit(exitCode);
	} // main ends here
}